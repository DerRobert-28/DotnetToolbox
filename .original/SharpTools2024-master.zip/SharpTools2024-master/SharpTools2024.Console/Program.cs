﻿namespace SharpTools2024.Console;

using static System.Console; 

class Program
{
	static void Main(string[] args)
	{
		WriteLine("hallo");
		ReadLine();
	}
}
