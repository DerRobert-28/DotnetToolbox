﻿namespace SharpTools2024.Exceptions;

internal class SizeOfException: Exception
{
	public SizeOfException(string message): base(message) {}
}
